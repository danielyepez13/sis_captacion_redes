$(function () {
  $("#configurar_datos").validate({
    // Para validar hace falta que el name y el id sean iguales dentro del formulario
    rules: {
      nombre_datos: {
        required: true,
      },
      apellido_datos: {
        required: true,
      },
      cedula_datos: {
        required: true,
        number: true,
        maxlength: 9,
      },
      rol_datos: {
        required: true,
      },
    },
  });
  $("#configurar_pass").validate({
    // Para validar hace falta que el name y el id sean iguales dentro del formulario
    rules: {
      contra: {
        required: true,
      },
      contra_rep: {
        required: true,
        equalTo: "#contra"
      },
    },
  });
});

// Chequea que no hayan numeros
function letras(e) {
  tecla = document.all ? e.keyCode : e.which;

  //Permite la tecla de retroceso, la ñ, el espacio
  if (tecla == 8 || tecla == 241 || tecla == 32) {
    return true;
  }

  // Patrón de entrada, en este caso solo acepta numeros y letras
  patron = /[A-Za-z]/;
  tecla_final = String.fromCharCode(tecla);
  return patron.test(tecla_final);
}
