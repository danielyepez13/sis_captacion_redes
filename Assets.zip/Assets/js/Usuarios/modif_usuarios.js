$(document).ready(function () {
  var cant_registros = $("#cant_registros").val();
  
  for (var i = 1; i <= cant_registros; i++) {
    $("#editar" + i).click(function (e) {
      var usuario =  $(this).val(); 

      // Envía los datos para la función del controlador a través del AJAX
      $.ajax({
        type: "POST",
        url: "../Usuarios/editar",
        data: {
          editar: usuario,
        },
        dataType: "json",
        beforeSend: function () {
          $("#nombre_edit").val("Esperando datos...");
          $("#apellido_edit").val("Esperando datos...");
          $("#rol_edit").html("<option>Esperando datos...</option>");
          $("#cedula_edit").val("Esperando datos...");
        },
        success: function (response) {
          $("#nombre_edit").val(response.nombre);
          $("#apellido_edit").val(response.apellido);
          $("#rol_edit").html(response.rol);
          $("#cargo_modif").html(response.cargo);
          $("#cedula_edit").val(response.cedula);
          $("#id_usuario_edit").val(response.id_usuario);
        },
      });
    });
  }

  // $("#modificar").click(function (e) {
  //   var usuario = $('#id_usuario_edit').val();
  //   var nombre = $("#nombre_edit").val();
  //   var apellido = $("#apellido_edit").val();
  //   var rol = $("#rol_edit").val();
  //   var cedula = $("#cedula_edit").val();
  //   var contra = $("#contra_edit").val();

  //   // Envía los datos para la función del controlador a través del AJAX
  //   $.ajax({
  //     type: "POST",
  //     url: "../Usuarios/modificar",
  //     data: {
  //       id_usuario: usuario,
  //       nombre: nombre,
  //       apellido: apellido,
  //       rol: rol,
  //       cedula: cedula,
  //       contra: contra,
  //     },
  //     dataType: "json",
  //     success: function (response) {
  //       // Se redirecciona a la lista y se coloca la respuesta como una variable
  //       $(location).attr(
  //         "href",
  //         "../Usuarios/listar?msg=" + response.respuesta
  //       );
  //     },
  //   });
  // });
});
