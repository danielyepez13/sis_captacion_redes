$(document).ready(function() {
    var cant_registros = $('#cant_registros').val()

    for (var i = 1; i <= cant_registros; i++) {
        $('#ver'+i).click(function (e) {
            e.preventDefault();
            var user = $(this).val();

            // Envía los datos para la función del controlador a través del AJAX
            $.ajax({
                type: "POST",
                url: "../Usuarios/ver",
                data: {
                    user: user,
                },
                dataType: "json",
                beforeSend: function(){
                    $('#nombre').text('Esperando datos...');
                    $('#cedula').text('Esperando datos...');
                    $('#rol').text('Esperando datos...');
                    $('#fecha_registro').text('Esperando datos...');
                    $('#hora_registro').text('Esperando datos...');
                    $('#estatus_usuario').text('Esperando datos...');
                },
                success: function(response) {
                    $('#nombre').text("Nombre y apellido: "+response.nombre);
                    $('#cedula').text("Cédula: "+response.cedula);
                    $('#rol').text("Rol del usuario: "+response.rol);
                    if(response.rol == 'Usuario'){
                        $('#cargo').text("Cargo a postular: "+response.cargo)
                    }
                    $('#fecha_registro').text("Fecha de registro: "+response.fecha_registro);
                    $('#hora_registro').text("Hora de registro: "+response.hora_registro);
                    $('#estatus_usuario').text("Estatus del usuario: "+response.estatus_usuario);
                }
            })
        })
    }
});