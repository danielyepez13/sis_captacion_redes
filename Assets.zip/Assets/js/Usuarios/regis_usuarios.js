$(document).ready(function() {

    $("#crear").click(function (e) {
  
        // Envía los datos para la función del controlador a través del AJAX
        $.ajax({
          type: "POST",
          url: "../Usuarios/registrar",
          dataType: "json",
          beforeSend: function () {
            $("#rol_regis").html("<option>Esperando datos...</option>");
          },
          success: function (response) {
            $("#rol_regis").html(response.rol);
          },
        });
      });

    // $('#registrar').click(function(e) {

    //     // Obtiene los valores de las variables
    //     var nombre = $("#nombre_regis").val();
    //     var apellido = $("#apellido_regis").val();
    //     var cedula = $("#cedula_regis").val();
    //     var contrasena = $("#contrasena_regis").val();
    //     var rol = $("#rol_regis").val();

    //     // Envía los datos para la función del controlador a través del AJAX
    //     $.ajax({
    //         type: "POST",
    //         url: "../Usuarios/insertar",
    //         data: {
    //             nombre: nombre,
    //             apellido: apellido,
    //             cedula: cedula,
    //             contrasena: contrasena,
    //             rol: rol
    //         },
    //         dataType: "json",
    //         success: function(response) {
    //             // Se redirecciona a la lista y se coloca la respuesta como una variable
    //             $(location).attr('href', '../Usuarios/listar?msg=' + response.respuesta);
    //         }
    //     });
    // });
});