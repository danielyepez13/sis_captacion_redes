$(document).ready(function () {
    $('#login').validate({
        rules: {
            cedula: {
                required: true
            },
            contra: {
                required: true
            },
        }
    });
    $('#correorecuperacion').validate({
        rules: {
            correo: {
                required: true,
                email: true
            },
        }
    });
    $("#recuperar").validate({
    // Para validar hace falta que el name y el id sean iguales dentro del formulario
    rules: {
        cedula: {
            required: true
        },
        contra: {
            required: true,
        },
        contra_rep: {
            required: true,
            equalTo: "#contra"
        },
    },
  });
});