$(document).ready(function() {
  var cant_registros = $('#cant_registros').val()

  for (var i = 1; i <= cant_registros; i++) {
      $('#revisar'+i).click(function (e) {  
          e.preventDefault();
          var revisar = $(this).attr('href');
          var arr = revisar.split('/');
          var prueba = arr[3];
          
          // console.log(pruebas)
          // Envía los datos para la función del controlador a través del AJAX
          $.ajax({
              type: "POST",
              url: "../Pruebas/revisar",
              data: {
                  revisar: prueba,
              },
              dataType: "json",
              // beforeSend: function(){
              //     $('#nombre_evaluador').text('Esperando datos...');
              //     $('#nombre_evaluado').text('Esperando datos...');
              //     $('#fecha_reg_prue').text('Esperando datos...');
              //     $('#hora_reg_prue').text('Esperando datos...');
              //     $('#estatus_pruebas').text('Esperando datos...');
              // },
              success: function(response) {
                  $('#contenedor').html(response.tab);
                  $('.pasos').html(response.paso)
                  $('.confirmar').html('<a href="../Pruebas/puntuar/'+prueba+'" class="btn btn-success">Confirmar</a>');
              }
          })
      })
  }
});

var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab
function showTab(n) {
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("cont");
  document.getElementById("sigBtn").innerHTML = "Siguiente";
 
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("previoBtn").style.display = "none";
  } else {

    document.getElementById("previoBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    // document.getElementById("sigBtn").innerHTML = "Siguiente";
    document.getElementById("sigBtn").style.display = "none";
    // document.getElementById("sigBtn").setAttribute("disabled", "");
    // $('#nexBtn').attr('disabled', true)
  }else{
    document.getElementById("sigBtn").style.display = "inline";
  }
  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function sigPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("cont");
  // Exit the function if any field in the current tab is invalid:
  // if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if (currentTab >= x.length) {
  //   document.getElementById("sigBtn").setAttribute("disabled", "disabled");
  // }else{
  //   document.getElementById("sigBtn").setAttribute("disabled", "");
  // }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

// function validateForm() {
//   // This function deals with validation of the form fields
//   var x, y, i, valid = true;
//   x = document.getElementsByClassName("cont");
//   y = x[currentTab].getElementsByClassName("answer");
//   // console.log(y)
//   // A loop that checks every input field in the current tab:
//   for (i = 0; i < y.length; i++) {
//     // If a field is empty...
//     if (y[i].value == "") {
//       // add an "invalid" class to the field:
//       y[i].className += " invalid";
//       // and set the current valid status to false:
//       valid = false;
//     }
//   }
//   // If the valid status is true, mark the step as finished and valid:
//   if (valid) {
//     document.getElementsByClassName("paso")[currentTab].className += " finish";
//   }
//   return valid; // return the valid status
// }

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("paso");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}