$(document).ready(function() {
    var cant_registros = $('#cant_registros').val()

    for (var i = 1; i <= cant_registros; i++) {
        $('#ver'+i).click(function (e) {
            e.preventDefault();
            var pruebas = $(this).val();
            // console.log(pruebas)
            // Envía los datos para la función del controlador a través del AJAX
            $.ajax({
                type: "POST",
                url: "../Pruebas/ver",
                data: {
                    pruebas: pruebas,
                },
                dataType: "json",
                beforeSend: function(){
                    $('#nombre_evaluador').text('Esperando datos...');
                    $('#nombre_evaluado').text('Esperando datos...');
                    $('#fecha_reg_prue').text('Esperando datos...');
                    $('#hora_reg_prue').text('Esperando datos...');
                    $('#estatus_pruebas').text('Esperando datos...');
                },
                success: function(response) {
                    $('#nombre_evaluador').text("Registrador: "+response.evaluador);
                    $('#nombre_evaluado').text("Evaluado: "+response.evaluado);
                    $('#cargo').text('Cargo a postular: '+response.cargo);
                    $('#fecha_reg_prue').text("Fecha registro: "+response.fecha_reg_prue);
                    $('#hora_reg_prue').text("Hora de registro: "+response.hora_reg_prue);
                    // Solo se enseñará cuando haya finalizado la prueba
                    if(response.estatus_prueba == 'Finalizada'){
                        $('#cant_resp_correctas').text("Cantidad de respuestas correctas: "+response.cant_resp_correctas);
                        $('#aprobo').text('El usuario '+response.aprobo+'.')
                        // $('#fecha_final').text("Fecha de finalización: "+response.fecha_final);
                    }
                    $('#estatus_pruebas').text("Estatus de la prueba: "+response.estatus_prueba);
                }
            })
        })
    }
});