// == Cuenta regresiva ==//
// Cuenta Regresiva para la prueba
// 45 mins
window.onload = function () {
    var seconds = 0o0;
    var tens = 0o0;
    var minutes = 0o0;
    var appendTens = document.getElementById("tens")
    var appendSeconds = document.getElementById("seconds")
    var appendMins = document.getElementById("minutes")
    var Interval;
  
    // Empezar contador
    clearInterval(Interval);
    Interval = setInterval(startTimer, 10);
  
    function startTimer() {
      tens++;
  
      if (tens <= 9) {
        appendTens.innerHTML = "0" + tens;
      }
  
      if (tens > 9) {
        appendTens.innerHTML = tens;
      }
  
      if (tens > 99) {
        // console.log("seconds");
        seconds++;
        appendSeconds.innerHTML = "0" + seconds;
        tens = 0;
        appendTens.innerHTML = "0" + 0;
      }
  
      if (seconds > 9) {
        appendSeconds.innerHTML = seconds;
      }
  
      if (seconds > 59) {
        // console.log("minutes")
        minutes++;
        appendMins.innerHTML = "0" + minutes;
        seconds = 0;
        appendSeconds.innerHTML = "0" + 0;
      }
      // Cuando se acabe el timepo que es de 45 minutos
      if (minutes > 44) {
        clearInterval(Interval);
        // Declaración de variables
        respuesta = [];
        hijo_res = [];
        correcta = [];
        hijo_cor = [];
        cant = $('#cant').val();
  
        // Bucle para listar las opciones
        for (let i = 0; i < cant; i++) {
          hijo_res = [];
          $('.respuesta' + i + ' .answer').each(function (index) {
            // element == this
            hijo_res.push($(this).val());
          });
          respuesta.push(hijo_res);
        }
  
        // bucle para listar respuestas correctas dadas por el usuario
        for (let i = 0; i < cant; i++) {
          hijo_cor = [];
          $('.correcta' + i + ' .question').each(function (index) {
            // element == this
            if ($(this).is(':checked')) {
              hijo_cor.push($(this).val());
            }
          });
          correcta.push(hijo_cor);
        }
        var tiempo = minutes + ':' + seconds;
  
        // Envío de array para guardar y mandar al usuario fuera del sistema
        $.ajax({
          type: "POST",
          url: "../Pruebas/revision",
          data: {
            respuesta: JSON.stringify(respuesta),
            correcta: JSON.stringify(correcta),
            tiempo: tiempo
          },
          dataType: "json",
          // beforeSend: function () {
          //   $("#evaluado").html("<option>Esperando datos...</option>");
          // },
          success: function (response) {
            // console.log(response.respuesta);
            // console.log(response.correcta);
            if (response.respuesta == 1) {
              location.href = "../Usuarios/logout/3";
            } else {
              location.href = "../Usuarios/logout/2";
              // console.log(response)
            }
          },
        });
      }
    }
  }