$(document).ready(function() {
    var cant_registros = $('#cant_registros').val()

    for (var i = 1; i <= cant_registros; i++) {
        $('#ver'+i).click(function (e) {
            e.preventDefault();
            var pregunta = $(this).val();

            // Envía los datos para la función del controlador a través del AJAX
            $.ajax({
                type: "POST",
                url: "../Preguntas/ver",
                data: {
                    pregunta: pregunta,
                },
                dataType: "json",
                beforeSend: function(){
                    $('#enunciado').text('Esperando datos...');
                    $('#respuestas').text('Esperando datos...');
                    $('#correctas').text('Esperando datos...');
                    $('#usuario').text('Esperando datos...');
                    $('#fecha_pregunta').text('Esperando datos...');
                    $('#hora_pregunta').text('Esperando datos...');
                    $('#estatus_pregunta').text('Esperando datos...');
                },
                success: function(response) {
                    $('#enunciado').text("Enunciado: "+response.enunciado);
                    $('#respuestas').text("Opciones: "+response.respuestas);
                    $('#correctas').text("Respuestas correctas: "+response.correctas);
                    $('#usuario').text("Usuario que registró: "+response.usuario);
                    $('#fecha_pregunta').text("Fecha de registro: "+response.fecha_pregunta);
                    $('#hora_pregunta').text("Hora de registro: "+response.hora_pregunta);
                    $('#estatus_pregunta').text("Estatus de la pregunta: "+response.estatus_pregunta);
                }
            })
        })
    }
});