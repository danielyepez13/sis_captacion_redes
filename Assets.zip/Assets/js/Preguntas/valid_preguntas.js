$(document).ready(function () {
    $("#registrar_usuarios").validate({
      // Para validar hace falta que el name y el id sean iguales dentro del formulario
      rules: {
        nombre_regis: {
          required: true,
        },
        apellido_regis: {
          required: true,
        },
        cedula_regis: {
          required: true,
          number: true,
          maxlength: 9
        },
        contrasena_regis: {
          required: true,
        },
        rol_regis: {
          required: true,
        }
      },
    });
    $("#modificar_usuarios").validate({
      // Para validar hace falta que el name y el id sean iguales dentro del formulario
      rules: {
        nombre_edit: {
          required: true,
        },
        apellido_edit: {
          required: true,
        },
        cedula_edit: {
          required: true,
          number: true,
          maxlength: 9
        },
        rol_edit: {
          required: true,
        }
      },
    });
  });
  
  // Chequea que no hayan numeros
  function letras(e) {
    tecla = document.all ? e.keyCode : e.which;
  
    //Permite la tecla de retroceso, la ñ, el espacio
    if (tecla == 8 || tecla == 241 || tecla == 32) {
      return true;
    }
  
    // Patrón de entrada, en este caso solo acepta numeros y letras
    patron = /[A-Za-z]/;
    tecla_final = String.fromCharCode(tecla);
    return patron.test(tecla_final);
  }
  