$(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = $(".input_fields_wrap"); //Fields wrapper
    var add_button      = $(".add_field_button"); //Add button ID
   
    var x = 1; //initial text box count
	
	
   $(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
	
		     //text box increment
            $(wrapper).append('<div class="d-flex mb-3"><div class="col-lg-6 respuesta pl-0"><input type="text" class="form-control" name="respuesta[]" value=""></div><div class="col-lg-3 correcta"><input type="checkbox" name="correcta[]" value="'+x+'"></div><a href="#" class="remove_field">Eliminar</a></div>'); //add input box
            x++; 
	  }						
    });
   
    $(wrapper).on("click",".remove_field", function(e){ //user click on remove text
       
		e.preventDefault(); 
		$(this).parent('div').remove(); 
		x--;
    })
});