$(document).ready(function () {
  var cant_registros = $("#cant_registros").val();

  var max_fields = 10; //maximum input boxes allowed
  var x = 1; //initial text box count

  var add_button = $(".add_field_button_edit"); //Add button ID

  for (var i = 1; i <= cant_registros; i++) {
    $("#editar" + i).click(function (e) {
      var pregunta = $(this).val();
      // console.log(pregunta)
      $("#contenedor").removeClass();
      $("#contenedor").addClass("input_fields_wrap_edit" + pregunta);
      var wrapper = $(".input_fields_wrap_edit" + pregunta);
      // Envía los datos para la función del controlador a través del AJAX
      $.ajax({
        type: "POST",
        url: "../Preguntas/editar",
        data: {
          editar: pregunta,
        },
        dataType: "json",
        beforeSend: function () {
          $("#enunciado_edit").val("Esperando datos...");
        },
        success: function (response) {
          // Asigna el valor del enunciado
          $("#enunciado_edit").val(response.enunciado);
          $("#id_pregunta_edit").val(response.id_pregunta);
          $('#correcta0').attr('checked', false);
          // Blanqueando contenedor de los campos duplicados
          $(wrapper).html('');
          x = 1;
          var checked = '';
          // Da formato a las respuestas correctas
          if (response.correctas.length > 1) {
            var correctas_multi = [];
            correctas_multi = response.correctas;

            // Coloca la respuesta correspondiente en el primer campo
            $("#respuesta0").val(response.respuestas[0]);
            // busca encontrar la posición 0 para saber si es una respuesta correcta
            var found = correctas_multi.indexOf('0');

            if (found > -1) {
              $('#correcta0').attr('checked', true);
              // Elimina el 0 del array de respuestas correctas
              correctas_multi.shift();
            } else {
              $('#correcta0').attr('checked', false);
            }
            // console.log(response.count_resp)
            // response.respuestas.shift();
            // Bucle mostrando los demás campos adicionales de opciones o respuestas
            a = 0;
            for (var i = 1; i <= response.count_resp - 1; i++) {
              if(response.respuestas[correctas_multi[a]] == response.respuestas[i]){
                $(wrapper).append('<div class="d-flex mb-3"><div class="col-lg-6 respuesta pl-0"><input type="text" class="form-control" name="respuesta_edit[]" id="respuesta' + x + '" value="' + response.respuestas[i] + '"></div><div class="col-lg-3 correcta"><input type="checkbox" id="correcta' + x + '" name="correcta_edit[]" value="' + x + '" checked></div><a href="#" class="remove_field">Eliminar</a></div>');
                a++;
              }
              else{
                $(wrapper).append('<div class="d-flex mb-3"><div class="col-lg-6 respuesta pl-0"><input type="text" class="form-control" name="respuesta_edit[]" id="respuesta' + x + '" value="' + response.respuestas[i] + '"></div><div class="col-lg-3 correcta"><input type="checkbox" id="correcta' + x + '" name="correcta_edit[]" value="' + x + '"></div><a href="#" class="remove_field">Eliminar</a></div>');
              }
              x++;

            }

          }
          else {
            // Escribir la respuesta correcta del enunciado siendo solo una
            var correctas_solo = response.correctas[0];
            // console.log(correctas_solo)
            // Bucle para colocar checked en la respuesta que sea correcta
            for (let k = 0; k < response.count_resp; k++) {
              if (k == 0) {
                $("#respuesta0").val(response.respuestas[k]);
                if (correctas_solo == 0) {
                  $('#correcta0').attr('checked', true);
                }
              } else {
                if (correctas_solo == k) {
                  $(wrapper).append('<div class="d-flex mb-3"><div class="col-lg-6 respuesta pl-0"><input type="text" class="form-control" name="respuesta_edit[]" id="respuesta' + x + '" value="' + response.respuestas[k] + '"></div><div class="col-lg-3 correcta"><input type="checkbox" id="correcta' + x + '" name="correcta_edit[]" value="' + x + '" checked></div><a href="#" class="remove_field">Eliminar</a></div>');
                } else {
                  $(wrapper).append('<div class="d-flex mb-3"><div class="col-lg-6 respuesta pl-0"><input type="text" class="form-control" name="respuesta_edit[]" id="respuesta' + x + '" value="' + response.respuestas[k] + '"></div><div class="col-lg-3 correcta"><input type="checkbox" id="correcta' + x + '" name="correcta_edit[]" value="' + x + '" ></div><a href="#" class="remove_field">Eliminar</a></div>');
                }
                x++;
              }
            }
          }
        },
      });
      $(wrapper).on("click", ".remove_field", function (e) { //user click on remove text

        e.preventDefault();
        $(this).parent('div').remove();
        console.log($(this).parent('div'))
        x--;
      })
    });
  }

  $(add_button).click(function (e) { //on add input button click
    e.preventDefault();
    if (x < max_fields) { //max input box allowed
      //add input box
      $(wrapper).append('<div class="d-flex mb-3"><div class="col-lg-6 respuesta pl-0"><input type="text" class="form-control" name="respuesta_edit[]" id="respuesta' + x + '" value=""></div><div class="col-lg-3 correcta"><input type="checkbox" id="correcta' + x + '" name="correcta_edit[]" value="' + x + '"></div><a href="#" class="remove_field">Eliminar</a></div>');
      x++;
    }
  });


});
